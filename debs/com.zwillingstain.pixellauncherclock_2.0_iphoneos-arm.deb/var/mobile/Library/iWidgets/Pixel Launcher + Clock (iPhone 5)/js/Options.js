var alldark = ;
var hidedate = ;
var hidetime = ;
var hideboth = ;